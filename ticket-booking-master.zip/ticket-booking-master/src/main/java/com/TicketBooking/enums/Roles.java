package com.TicketBooking.enums;

import lombok.Data;


public enum Roles {
    ROLE_ADMIN,
    ROLE_USER,
    ROLE_MANAGER
}
