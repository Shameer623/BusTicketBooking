package com.TicketBooking.exception;

public class ResourseNotFoundException extends RuntimeException {
    public ResourseNotFoundException(String s) {
        super(s);
    }
}
